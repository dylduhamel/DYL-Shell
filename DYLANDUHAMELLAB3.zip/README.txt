Dylan Duhamel
CSC-251 Lab 3

The purpose of this lab is to take our previously existant shell program
and add execvp, fork, and pipe functionality. This allows the shell to use
children to execute commands and even chain multiple together with pipe
functionality.

cc DylanDuhamel_lab3.c
./a.out
